
export interface StudentResponse {
  id: number;
  name: string;
  className: string;
  emoji: string;
  text?: string;
}
